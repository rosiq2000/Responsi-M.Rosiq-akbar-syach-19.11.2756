﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectPenjualan
{
    public class Penjualan
    {
        // PERINTAH: lengkapi property class penjualan, sesuai petunjuk soal
        public string nota { get; set; }
        public string tanggal { get; set; }
        public string customer { get; set; }
        public string jenis { get; set; }
        public double total { get; set; }
    }
}
